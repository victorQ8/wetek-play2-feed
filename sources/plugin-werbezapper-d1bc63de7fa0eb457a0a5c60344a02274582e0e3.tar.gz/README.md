

# <p align="center">WerbeZapper Plugin for Enigma2 (E²) ![GitHub repo size](https://img.shields.io/github/repo-size/oe-alliance-plugins/WerbeZapper.svg)</p>

**Werbezapper-Plugin for Enigma2**


## Github status
[![Build](https://github.com/oe-alliance-plugins/WerbeZapper/actions/workflows/buildbot.yml/badge.svg)](https://github.com/oe-alliance-plugins/WerbeZapper/actions/workflows/buildbot.yml)
[![Lint Status](https://github.com/oe-alliance-plugins/WerbeZapper/actions/workflows/pylint.yml/badge.svg)](https://github.com/oe-alliance-plugins/WerbeZapper/actions/workflows/pylint.yml)
[![Ruff Status](https://github.com/oe-alliance-plugins/WerbeZapper/actions/workflows/ruff.yml/badge.svg)](https://github.com/oe-alliance-plugins/WerbeZapper/actions/workflows/ruff.yml)
[![Build Status](https://github.com/oe-alliance-plugins/WerbeZapper/actions/workflows/compile.yml/badge.svg)](https://github.com/oe-alliance-plugins/WerbeZapper/actions/workflows/compile.yml)
[![AUTOTAG](https://github.com/oe-alliance-plugins/WerbeZapper/actions/workflows/autotag.yml/badge.svg)](https://github.com/oe-alliance-plugins/WerbeZapper/actions/workflows/autotag.yml)


[![Plugin Version](https://img.shields.io/github/v/tag/oe-alliance-plugins/WerbeZapper?label=Latest%20Version&color=darkviolet)](https://github.com/oe-alliance-plugins/WerbeZapper/tags)
[![Latest Release](https://img.shields.io/github/release-date/oe-alliance-plugins/WerbeZapper?label=From&color=darkviolet)](https://github.com/oe-alliance-plugins/WerbeZapper/releases/latest)
[![Github last commit](https://img.shields.io/github/last-commit/oe-alliance-plugins/WerbeZapper)](https://github.com/oe-alliance-plugins/WerbeZapper)
[![GitHub Activity](https://img.shields.io/github/commit-activity/y/oe-alliance-plugins/WerbeZapper.svg?label=commits)](https://github.com/oe-alliance-plugins/WerbeZapper/commits)
[![GitHub Activity](https://img.shields.io/github/commit-activity/m/oe-alliance-plugins/WerbeZapper.svg?label=commits)](https://github.com/oe-alliance-plugins/WerbeZapper/commits)

## SonarCloud status
[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=oe-alliance-plugins_WerbeZapper&metric=alert_status)](https://sonarcloud.io/summary/new_code?id=oe-alliance-plugins_WerbeZapper)
[![Vulnerabilities](https://sonarcloud.io/api/project_badges/measure?project=oe-alliance-plugins_WerbeZapper&metric=vulnerabilities)](https://sonarcloud.io/summary/new_code?id=oe-alliance-plugins_WerbeZapper)
[![Security Rating](https://sonarcloud.io/api/project_badges/measure?project=oe-alliance-plugins_WerbeZapper&metric=security_rating)](https://sonarcloud.io/summary/new_code?id=oe-alliance-plugins_WerbeZapper)
[![Bugs](https://sonarcloud.io/api/project_badges/measure?project=oe-alliance-plugins_WerbeZapper&metric=bugs)](https://sonarcloud.io/summary/new_code?id=oe-alliance-plugins_WerbeZapper)
[![Code Smells](https://sonarcloud.io/api/project_badges/measure?project=oe-alliance-plugins_WerbeZapper&metric=code_smells)](https://sonarcloud.io/summary/new_code?id=oe-alliance-plugins_WerbeZapper)
[![Duplicated Lines (%)](https://sonarcloud.io/api/project_badges/measure?project=oe-alliance-plugins_WerbeZapper&metric=duplicated_lines_density)](https://sonarcloud.io/summary/new_code?id=oe-alliance-plugins_WerbeZapper)
[![Reliability Rating](https://sonarcloud.io/api/project_badges/measure?project=oe-alliance-plugins_WerbeZapper&metric=reliability_rating)](https://sonarcloud.io/summary/new_code?id=oe-alliance-plugins_WerbeZapper)
[![Maintainability Rating](https://sonarcloud.io/api/project_badges/measure?project=oe-alliance-plugins_WerbeZapper&metric=sqale_rating)](https://sonarcloud.io/summary/new_code?id=oe-alliance-plugins_WerbeZapper)

[![SonarQube Cloud](https://sonarcloud.io/images/project_badges/sonarcloud-light.svg)](https://sonarcloud.io/summary/new_code?id=oe-alliance-plugins_WerbeZapper)

---

### 📜 License Information [![License: CC BY-NC-SA 3.0](https://img.shields.io/badge/License-CC%20BY--NC--SA%203.0-lightgrey.svg)](https://creativecommons.org/licenses/by-nc-sa/3.0/)

This plugin is NOT free software. It is open source and licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.

This plugin is released under CC BY-NC-SA 3.0. See [LICENSE](LICENSE.txt) for full details.

---

### 🤝 Contributing & Contact

WerbeZapper is created by users for users and we welcome every contribution. There are no highly paid developers. There are only users who have seen a problem and done their best to fix it. This means WerbeZapper will always need the contributions of users like you. How can you get involved?

For questions or feedback, feel free and please open an issue or contribute with a Pull Request!

Pull requests are very welcome for:
- **Coding:** Developers can help by fixing a bug, adding new features, Integration improvements, Feature enhancements
- **Localization:** Translate into your native language.
- **Helping users:** Our support process relies on enthusiastic contributors like you to help others.

Your contribution is very welcome! Follow these steps:

1. 🍴 Fork this repository
2. 🔄 Create a branch for your feature
3. 💻 Make your changes
4. ✅ Commit using conventional messages
5. 📤 Push to your branch
6. 🔍 Open a Pull Request

Enjoy and help us improve it today. :)

### 🚨 Disclaimer

The project author is not responsible for how this software is used by others. It is not intended to be used for accessing or distributing copyrighted materials without authorization.
Users are solely responsible for determining the legality of their actions.

This repository has no control over the streams, links, or the legality of the content provided by the different hosts (including all mirror sites). It is the end user's responsibility to ensure the legal use of these streams, and we strongly recommend verifying that the content complies with all applicable laws, including copyright laws and regulations of your countrys jurisdiction before use.

---

### 🤝 Contributing Details

For detailed contributing guidelines including testing procedures and AI policy, please see [CONTRIBUTING.md](https://github.com/oe-alliance-plugins/.github/blob/main/docs/CONTRIBUTING.md).

---

⭐️ If you find this plugin useful, please give it a star on GitHub!
Thanks! ❤️ 💞 💖 ❤️‍🔥 💗
