

# <p align="center">Partnerbox Plugin for Enigma2 (E²) ![GitHub repo size](https://img.shields.io/github/repo-size/oe-alliance-plugins/Partnerbox.svg)</p>

**Partnerbox (Remote Bouquets, Channels, Timers and TV Player)**


## Github status
[![Build](https://github.com/oe-alliance-plugins/Partnerbox/actions/workflows/buildbot.yml/badge.svg)](https://github.com/oe-alliance-plugins/Partnerbox/actions/workflows/buildbot.yml)
[![Lint Status](https://github.com/oe-alliance-plugins/Partnerbox/actions/workflows/pylint.yml/badge.svg)](https://github.com/oe-alliance-plugins/Partnerbox/actions/workflows/pylint.yml)
[![Ruff Status](https://github.com/oe-alliance-plugins/Partnerbox/actions/workflows/ruff.yml/badge.svg)](https://github.com/oe-alliance-plugins/Partnerbox/actions/workflows/ruff.yml)
[![Build Status](https://github.com/oe-alliance-plugins/Partnerbox/actions/workflows/compile.yml/badge.svg)](https://github.com/oe-alliance-plugins/Partnerbox/actions/workflows/compile.yml)
[![AUTOTAG](https://github.com/oe-alliance-plugins/Partnerbox/actions/workflows/autotag.yml/badge.svg)](https://github.com/oe-alliance-plugins/Partnerbox/actions/workflows/autotag.yml)


[![Plugin Version](https://img.shields.io/github/v/tag/oe-alliance-plugins/Partnerbox?label=Latest%20Version&color=darkviolet)](https://github.com/oe-alliance-plugins/Partnerbox/tags)
[![Latest Release](https://img.shields.io/github/release-date/oe-alliance-plugins/Partnerbox?label=From&color=darkviolet)](https://github.com/oe-alliance-plugins/Partnerbox/releases/latest)
[![Github last commit](https://img.shields.io/github/last-commit/oe-alliance-plugins/Partnerbox)](https://github.com/oe-alliance-plugins/Partnerbox)
[![GitHub Activity](https://img.shields.io/github/commit-activity/y/oe-alliance-plugins/Partnerbox.svg?label=commits)](https://github.com/oe-alliance-plugins/Partnerbox/commits)
[![GitHub Activity](https://img.shields.io/github/commit-activity/m/oe-alliance-plugins/Partnerbox.svg?label=commits)](https://github.com/oe-alliance-plugins/Partnerbox/commits)

## SonarCloud status
[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=oe-alliance-plugins_Partnerbox&metric=alert_status)](https://sonarcloud.io/summary/new_code?id=oe-alliance-plugins_Partnerbox)
[![Vulnerabilities](https://sonarcloud.io/api/project_badges/measure?project=oe-alliance-plugins_Partnerbox&metric=vulnerabilities)](https://sonarcloud.io/summary/new_code?id=oe-alliance-plugins_Partnerbox)
[![Security Rating](https://sonarcloud.io/api/project_badges/measure?project=oe-alliance-plugins_Partnerbox&metric=security_rating)](https://sonarcloud.io/summary/new_code?id=oe-alliance-plugins_Partnerbox)
[![Bugs](https://sonarcloud.io/api/project_badges/measure?project=oe-alliance-plugins_Partnerbox&metric=bugs)](https://sonarcloud.io/summary/new_code?id=oe-alliance-plugins_Partnerbox)
[![Code Smells](https://sonarcloud.io/api/project_badges/measure?project=oe-alliance-plugins_Partnerbox&metric=code_smells)](https://sonarcloud.io/summary/new_code?id=oe-alliance-plugins_Partnerbox)
[![Duplicated Lines (%)](https://sonarcloud.io/api/project_badges/measure?project=oe-alliance-plugins_Partnerbox&metric=duplicated_lines_density)](https://sonarcloud.io/summary/new_code?id=oe-alliance-plugins_Partnerbox)
[![Reliability Rating](https://sonarcloud.io/api/project_badges/measure?project=oe-alliance-plugins_Partnerbox&metric=reliability_rating)](https://sonarcloud.io/summary/new_code?id=oe-alliance-plugins_Partnerbox)
[![Maintainability Rating](https://sonarcloud.io/api/project_badges/measure?project=oe-alliance-plugins_Partnerbox&metric=sqale_rating)](https://sonarcloud.io/summary/new_code?id=oe-alliance-plugins_Partnerbox)

[![SonarQube Cloud](https://sonarcloud.io/images/project_badges/sonarcloud-light.svg)](https://sonarcloud.io/summary/new_code?id=oe-alliance-plugins_Partnerbox)

---

### 📜 License Information [![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)

This is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation

This plugin is released under GPLv3. See [LICENSE](https://www.gnu.org/licenses/gpl-3.0.html#license-text) for full details.

<img width="120" height="58" alt="GPLv3_Logo svg" src="https://github.com/user-attachments/assets/67d32b0a-2a44-4fa9-a972-202daf28808e" />

---

### 🤝 Contributing & Contact

Partnerbox is created by users for users and we welcome every contribution. There are no highly paid developers. There are only users who have seen a problem and done their best to fix it. This means Partnerbox will always need the contributions of users like you. How can you get involved?

For questions or feedback, feel free and please open an issue or contribute with a Pull Request!

Pull requests are very welcome for:
- **Coding:** Developers can help by fixing a bug, adding new features, Integration improvements, Feature enhancements
- **Localization:** Translate into your native language.
- **Helping users:** Our support process relies on enthusiastic contributors like you to help others.

Your contribution is very welcome! Follow these steps:

1. 🍴 Fork this repository
2. 🔄 Create a branch for your feature
3. 💻 Make your changes
4. ✅ Commit using conventional messages
5. 📤 Push to your branch
6. 🔍 Open a Pull Request

Enjoy and help us improve it today. :)

### 🚨 Disclaimer

The project author is not responsible for how this software is used by others. It is not intended to be used for accessing or distributing copyrighted materials without authorization.
Users are solely responsible for determining the legality of their actions.

This repository has no control over the streams, links, or the legality of the content provided by the different hosts (including all mirror sites). It is the end user's responsibility to ensure the legal use of these streams, and we strongly recommend verifying that the content complies with all applicable laws, including copyright laws and regulations of your countrys jurisdiction before use.

---

### 🤝 Contributing Details

For detailed contributing guidelines including testing procedures and AI policy, please see [CONTRIBUTING.md](https://github.com/oe-alliance-plugins/.github/blob/main/docs/CONTRIBUTING.md).

---

⭐️ If you find this plugin useful, please give it a star on GitHub!
Thanks! ❤️ 💞 💖 ❤️‍🔥 💗
