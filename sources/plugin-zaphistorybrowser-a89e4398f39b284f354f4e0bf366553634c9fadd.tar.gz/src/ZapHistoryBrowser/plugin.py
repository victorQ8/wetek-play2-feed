# -*- coding: UTF-8 -*-
## Zap-History Browser by AliAbdul
from Components.ActionMap import ActionMap
from Components.config import (
    config,
    ConfigInteger,
    ConfigSelection,
    ConfigYesNo,
    ConfigSet,
    ConfigSubsection,
    getConfigListEntry,
)
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.Language import language
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from Components.ParentalControl import parentalControl
from enigma import (
    eListboxPythonMultiContent,
    eServiceCenter,
    eServiceReference,
    gFont,
    getDesktop,
)
from Plugins.Plugin import PluginDescriptor
from Screens.ChannelSelection import ChannelSelection
from Screens.ParentalControlSetup import ProtectedScreen
from Screens.Screen import Screen
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
import gettext
from skin import parameters as skinparameter

################################################

PluginLanguageDomain = "ZapHistoryBrowser"
PluginLanguagePath = "Extensions/ZapHistoryBrowser/locale/"


def localeInit():
    gettext.bindtextdomain(PluginLanguageDomain, resolveFilename(SCOPE_PLUGINS, PluginLanguagePath))


def _(txt):
    translated = gettext.dgettext(PluginLanguageDomain, txt)
    if translated:
        return translated
    print("[%s] fallback to default translation for %s" % (PluginLanguageDomain, txt))
    return gettext.gettext(txt)


localeInit()
language.addCallback(localeInit)

################################################

config.plugins.ZapHistoryConfigurator = ConfigSubsection()
config.plugins.ZapHistoryConfigurator.enable_zap_history = ConfigSelection(
    choices={
        "off": _("disabled"),
        "on": _("enabled"),
        "parental_lock": _("disabled at parental lock"),
    },
    default="on",
)
config.plugins.ZapHistoryConfigurator.maxEntries_zap_history = ConfigInteger(default=20, limits=(1, 60))
config.plugins.ZapHistoryConfigurator.e1_like_history = ConfigYesNo(default=False)
config.plugins.ZapHistoryConfigurator.history_tv = ConfigSet(choices=[])
config.plugins.ZapHistoryConfigurator.history_radio = ConfigSet(choices=[])

################################################


def addToHistory(instance, ref):
    if config.plugins.ZapHistoryConfigurator.enable_zap_history.value == "off":
        return
    if config.ParentalControl.servicepinactive.value and config.plugins.ZapHistoryConfigurator.enable_zap_history.value == "parental_lock":
        if parentalControl.getProtectionLevel(ref.toCompareString()) != -1:
            return
    if instance.servicePath is not None:
        tmp = instance.servicePath[:]
        tmp.append(ref)
        try:
            del instance.history[instance.history_pos + 1:]
        except Exception:
            pass
        if config.plugins.ZapHistoryConfigurator.e1_like_history.value and tmp in instance.history:
            instance.history.remove(tmp)
        instance.history.append(tmp)
        history_length = len(instance.history)
        if history_length > config.plugins.ZapHistoryConfigurator.maxEntries_zap_history.value:
            del instance.history[0]
            history_length -= 1
        instance.history_pos = history_length - 1
        if config.plugins.ZapHistoryConfigurator.e1_like_history.value:
            # TODO: optimize this
            if instance.history == instance.history_tv:
                config.plugins.ZapHistoryConfigurator.history_tv.value = [[entry.toString() for entry in item] for item in instance.history]
            else:
                config.plugins.ZapHistoryConfigurator.history_radio.value = [[entry.toString() for entry in item] for item in instance.history]
            config.plugins.ZapHistoryConfigurator.save()


ChannelSelection.addToHistory = addToHistory


baseInit = ChannelSelection.__init__


def newInit(self, session):
    baseInit(self, session)
    if config.plugins.ZapHistoryConfigurator.e1_like_history.value:
        append_tv = self.history_tv.append
        for item in config.plugins.ZapHistoryConfigurator.history_tv.value:
            append_tv([eServiceReference(ref) for ref in item])
        append_radio = self.history_radio.append
        for item in config.plugins.ZapHistoryConfigurator.history_radio.value:
            append_radio([eServiceReference(ref) for ref in item])

        # XXX: self.lastChannelRootTimer was always finished for me, so just fix its mistakes ;)
        if self.history == self.history_tv:
            self.history_pos = len(self.history_tv) - 1
        else:
            self.history_pos = len(self.history_radio) - 1


ChannelSelection.__init__ = newInit

################################################


class ZapHistoryConfigurator(ConfigListScreen, Screen):
    skin = """
        <screen position="center,center" size="420,80" title="%s" >
            <widget name="config" position="0,0" size="420,80" scrollbarMode="showOnDemand" />
        </screen>""" % _("Zap-History Configurator")

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        ConfigListScreen.__init__(self, [
            getConfigListEntry(_("Enable zap history:"), config.plugins.ZapHistoryConfigurator.enable_zap_history),
            getConfigListEntry(_("Maximum zap history entries:"), config.plugins.ZapHistoryConfigurator.maxEntries_zap_history),
            getConfigListEntry(_("Enigma1-like history:"), config.plugins.ZapHistoryConfigurator.e1_like_history),
        ])

        self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.save, "cancel": self.exit}, -2)

    def save(self):
        # alternative to notifier
        if config.plugins.ZapHistoryConfigurator.e1_like_history.value and config.plugins.ZapHistoryConfigurator.e1_like_history.isChanged():
            from Screens.InfoBar import InfoBar
            try:
                csel = InfoBar.instance.servicelist
            except AttributeError:
                pass
            else:
                config.plugins.ZapHistoryConfigurator.history_tv.value = [[entry.toString() for entry in item] for item in csel.history_tv]
                config.plugins.ZapHistoryConfigurator.history_radio.value = [[entry.toString() for entry in item] for item in csel.history_radio]
                config.plugins.ZapHistoryConfigurator.history_tv.save()
                config.plugins.ZapHistoryConfigurator.history_radio.save()

        for entry in self["config"].list:
            entry[1].save()
        self.close()

    def exit(self):
        for entry in self["config"].list:
            entry[1].cancel()
        self.close()

################################################


class ZapHistoryBrowserList(MenuList):
    def __init__(self, items, enableWrapAround=False):
        MenuList.__init__(self, items, enableWrapAround, eListboxPythonMultiContent)
        desktop_width = getDesktop(0).size().width()
        if desktop_width <= 1280:
            font1, size1 = skinparameter.get("ZapHistoryBrowserListFont1", ('Regular', 20))
            font2, size2 = skinparameter.get("ZapHistoryBrowserListFont2", ('Regular', 18))
            self.l.setFont(0, gFont(font1, size1))
            self.l.setFont(1, gFont(font2, size2))
            self.l.setItemHeight(40)
        else:
            font1, size1 = skinparameter.get("ZapHistoryBrowserListFont1", ('Regular', 30))
            font2, size2 = skinparameter.get("ZapHistoryBrowserListFont2", ('Regular', 27))
            self.l.setFont(0, gFont(font1, size1))
            self.l.setFont(1, gFont(font2, size2))
            self.l.setItemHeight(75)


def ZapHistoryBrowserListEntry(serviceName, eventName):
    result = [serviceName]
    desktop_width = getDesktop(0).size().width()
    if desktop_width <= 1280:
        x1, y1, w1, h1 = skinparameter.get("ZapHistoryBrowserServiceName", (0, 0, 560, 22))
        x2, y2, w2, h2 = skinparameter.get("ZapHistoryBrowserEventName", (0, 22, 560, 18))
        result.append(MultiContentEntryText(pos=(x1, y1), size=(w1, h1), font=0, text=serviceName))
        result.append(MultiContentEntryText(pos=(x2, y2), size=(w2, h2), font=1, text=eventName))
    else:
        x1, y1, w1, h1 = skinparameter.get("ZapHistoryBrowserServiceName", (2, 1, 840, 38))
        x2, y2, w2, h2 = skinparameter.get("ZapHistoryBrowserEventName", (2, 40, 840, 33))
        result.append(MultiContentEntryText(pos=(x1, y1), size=(w1, h1), font=0, text=serviceName))
        result.append(MultiContentEntryText(pos=(x2, y2), size=(w2, h2), font=1, text=eventName))
    return result

################################################


class ZapHistoryBrowser(Screen, ProtectedScreen):
    skin = """
    <screen position="center,center" size="560,440" title="%s" >
        <ePixmap pixmap="skin_default/buttons/red.png" position="0,0" size="140,40" transparent="1" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/green.png" position="140,0" size="140,40" transparent="1" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/yellow.png" position="280,0" size="140,40" transparent="1" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/blue.png" position="420,0" size="140,40" transparent="1" alphatest="on" />
        <widget name="key_red" position="0,0" zPosition="1" size="140,40" font="Regular;20" valign="center" halign="center" backgroundColor="#1f771f" transparent="1" />
        <widget name="key_green" position="140,0" zPosition="1" size="140,40" font="Regular;20" valign="center" halign="center" backgroundColor="#1f771f" transparent="1" />
        <widget name="key_yellow" position="280,0" zPosition="1" size="140,40" font="Regular;20" valign="center" halign="center" backgroundColor="#1f771f" transparent="1" />
        <widget name="key_blue" position="420,0" zPosition="1" size="140,40" font="Regular;20" valign="center" halign="center" backgroundColor="#1f771f" transparent="1" />
        <widget name="list" position="0,40" size="560,400" scrollbarMode="showOnDemand" />
    </screen>""" % _("Zap-History Browser")

    def __init__(self, session, servicelist):
        Screen.__init__(self, session)
        ProtectedScreen.__init__(self)
        self.session = session

        self.servicelist = servicelist
        self.serviceHandler = eServiceCenter.getInstance()
        self.allowChanges = True

        self["list"] = ZapHistoryBrowserList([])
        self["key_red"] = Label(_("Clear"))
        self["key_green"] = Label(_("Delete"))
        self["key_yellow"] = Label(_("Zap"))
        self["key_blue"] = Label(_("Config"))

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"],
            {
                "ok": self.zapAndClose,
                "cancel": self.close,
                "red": self.clear,
                "green": self.delete,
                "yellow": self.zap,
                "blue": self.config,
            }, prio=-1)

        self.onLayoutFinish.append(self.buildList)

    def buildList(self):
        entries = []
        for item in self.servicelist.history:
            if len(item) == 2:  # Single-Bouquet
                ref = item[1]
            else:  # Multi-Bouquet
                ref = item[2]
            info = self.serviceHandler.info(ref)
            if info:
                name = info.getName(ref).replace('\xc2\x86', '').replace('\xc2\x87', '')
                event = info.getEvent(ref)
                if event is not None:
                    eventName = event.getEventName()
                    if eventName is None:
                        eventName = ""
                else:
                    eventName = ""
            else:
                name = "N/A"
                eventName = ""
            entries.append(ZapHistoryBrowserListEntry(name, eventName))
        entries.reverse()
        self["list"].setList(entries)

    def zap(self):
        history_length = len(self.servicelist.history)
        if history_length > 0:
            self.servicelist.history_pos = (history_length - self["list"].getSelectionIndex()) - 1
            self.servicelist.setHistoryPath()

    def clear(self):
        if self.allowChanges:
            for _ in range(len(self.servicelist.history)):
                del self.servicelist.history[0]
            self.buildList()
            self.servicelist.history_pos = 0

    def delete(self):
        if self.allowChanges:
            history_length = len(self.servicelist.history)
            if history_length > 0:
                idx = (history_length - self["list"].getSelectionIndex()) - 1
                del self.servicelist.history[idx]
                self.buildList()
                current_ref = self.session.nav.getCurrentlyPlayingServiceReference()
                idx = 0
                for item in self.servicelist.history:
                    if len(item) == 2:  # Single-Bouquet
                        ref = item[1]
                    else:  # Multi-Bouquet
                        ref = item[2]
                    if ref == current_ref:
                        self.servicelist.history_pos = idx
                        break
                    idx += 1

    def zapAndClose(self):
        self.zap()
        self.close()

    def config(self):
        if self.allowChanges:
            self.session.open(ZapHistoryConfigurator)

    def isProtected(self):
        return config.ParentalControl.setuppinactive.value

    def pinEntered(self, result):
        self.allowChanges = bool(result)

################################################


def main(session, servicelist, **kwargs):
    session.open(ZapHistoryBrowser, servicelist)


def Plugins(**kwargs):
    return PluginDescriptor(name=_("Zap-History Browser"), where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main)
