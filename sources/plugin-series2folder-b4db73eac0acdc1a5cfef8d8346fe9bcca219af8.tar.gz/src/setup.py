from setuptools import setup
import setup_translate

pkg = 'Extensions.Series2Folder'
setup(name='enigma2-plugin-extensions-series2folder',
       version='3.0',
       description='Move series recordings to folders',
       package_dir={pkg: 'Series2Folder'},
       packages=[pkg],
       package_data={pkg: ['images/*.png', '*.png', '*.xml', 'locale/*/LC_MESSAGES/*.mo', 'maintainer.info']},
       cmdclass=setup_translate.cmdclass,  # for translation
      )
